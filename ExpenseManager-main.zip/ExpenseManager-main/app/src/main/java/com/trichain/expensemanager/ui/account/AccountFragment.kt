package com.trichain.expensemanager.ui.account

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.DataProvider
import com.trichain.expensemanager.databinding.FragmentAccountBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.extension.toUSDFormatted
import com.trichain.expensemanager.ui.info.InfoFragment
import com.trichain.expensemanager.ui.overview.adapter.AccountOverviewAdapter
import com.trichain.rally_pie.RallyPieAnimation
import com.trichain.rally_pie.RallyPieData
import com.trichain.rally_pie.RallyPiePortion
//import kotlinx.android.synthetic.main.fragment_account.btn_info
//import kotlinx.android.synthetic.main.fragment_account.rallyPie
//import kotlinx.android.synthetic.main.fragment_account.rv_account
//import kotlinx.android.synthetic.main.fragment_account.tvAmount

/**
 * Created by Yoosin Paddy on 8/1/22.
 */

class AccountFragment : Fragment() {

  private val accountAdapter by lazy { AccountOverviewAdapter(isSingleLine = false) }
lateinit var b:FragmentAccountBinding

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    b= FragmentAccountBinding.inflate(inflater,container,false)
    return b.root
  }

  override fun onViewCreated(
    view: View,
    savedInstanceState: Bundle?
  ) {
    super.onViewCreated(view, savedInstanceState)

    setUpPieView()
    setUpRecyclerView()
    b.btnInfo.setOnClickListener {
      val infoFragment = InfoFragment()
      infoFragment.show(childFragmentManager, "AccountInfo")
    }
  }

  private fun setUpPieView() {

    b.tvAmount.text = DataProvider.accountOverView.total.toUSDFormatted()

    val rallyPiePortions = DataProvider.accountOverView.accounts.map {
      RallyPiePortion(
          it.name, it.amount, ContextCompat.getColor(requireContext(), it.color)
      )
    }
        .toList()

    val rallyPieData = RallyPieData(portions = rallyPiePortions)
    val rallyPieAnimation = RallyPieAnimation(b.rallyPie).apply {
      duration = 600
    }


    b.rallyPie.setPieData(pieData = rallyPieData, animation = rallyPieAnimation)
  }

  private fun setUpRecyclerView() {
    b.rvAccount.apply {
      layoutManager = LinearLayoutManager(requireContext())
      setHasFixedSize(true)
      addItemDecoration(getRallyItemDecoration())
      adapter = accountAdapter
    }
    accountAdapter.submitList(DataProvider.accountOverView.accounts)
  }

}
