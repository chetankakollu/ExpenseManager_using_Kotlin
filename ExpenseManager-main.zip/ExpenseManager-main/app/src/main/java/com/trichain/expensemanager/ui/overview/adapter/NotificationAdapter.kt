package com.trichain.expensemanager.ui.overview.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.model.Alert
import com.trichain.expensemanager.databinding.ItemAlertBinding
import com.trichain.expensemanager.room.tables.NotificationTable

/**
 * Created by lin min phyo on 2019-08-24.
 */

class NotificationAdapter(var list: List<NotificationTable>,var c:Context,var isFromDashboard:Boolean) : RecyclerView.Adapter<AlertViewHolder>() {

  override fun onCreateViewHolder(
    parent: ViewGroup,
    viewType: Int
  ): AlertViewHolder {
    return AlertViewHolder(ItemAlertBinding.inflate(LayoutInflater.from(c),parent,false))
  }

  override fun onBindViewHolder(
    holder: AlertViewHolder,
    position: Int
  ) {
    holder.b.tvAlert.text=list[position].info
    holder.itemView.setOnClickListener {
//      clickListener.invoke(getItem(position).alert)
    }
  }

  override fun getItemCount(): Int {
    return if (isFromDashboard){
      if (list.size>2){
        3
      }else{
        list.size
      }
    }else{
      list.size
    }
  }
}

class AlertViewHolder(view:  ItemAlertBinding) : RecyclerView.ViewHolder(view.root) {
  val b=view

}