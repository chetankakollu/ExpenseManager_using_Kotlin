package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.trichain.expensemanager.room.tables.*

@Dao
interface NotificationDao {
    @Insert(onConflict = REPLACE)
    fun insert(data: NotificationTable)

    @Delete
    fun delete(data: NotificationTable)

    @Update
    fun update(data: NotificationTable): Int

    @Query("SELECT * from NotificationTable ORDER BY id ASC")
    fun getAll(): List<NotificationTable>

    @Query("SELECT * from NotificationTable where username=:userId and categoryId=:categoryId and mDate like :mDate limit 1")
    fun getNotification(categoryId:Int,mDate:String,userId:Int): NotificationTable


    @Query("SELECT * from NotificationTable ORDER BY id ASC")
    fun getAllL(): LiveData<List<NotificationTable>>

    @Query("SELECT * FROM NotificationTable WHERE id = :id LIMIT 1")
    fun getNote(id: Int): NotificationTable

    @Query("DELETE FROM NotificationTable")
    fun deleteAll(): Int
}