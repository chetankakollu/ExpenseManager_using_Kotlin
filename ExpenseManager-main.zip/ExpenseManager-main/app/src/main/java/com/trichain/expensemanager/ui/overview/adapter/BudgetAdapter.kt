package com.trichain.expensemanager.ui.overview.adapter

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.databinding.ItemBudgetBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.ui.budget.BudgetFragment
import com.trichain.rally_line_indicator.RallyVerticalBarData

/**
 * Created by Yoosin Paddy on 7/31/22.
 */
class BudgetAdapter(
    var c: FragmentActivity,
    var list: List<BudgetTable>,
    var isDasBoard: Boolean,
    val param: BudgetFragment.OnBudgetUpdated
) :
    RecyclerView.Adapter<BudgetViewHolder>() {
    private val TAG = "BudgetAdapter"
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BudgetViewHolder {
        return BudgetViewHolder(ItemBudgetBinding.inflate(LayoutInflater.from(c), parent, false))
    }

    override fun onBindViewHolder(
        h: BudgetViewHolder,
        position: Int
    ) {
        getCategoryName(position, h.b)
        getRemaining(position, h.b)
        h.b.tvBudget.text = "$${list[position].amount.toString()}"

        h.itemView.setOnClickListener {
            param.budgetClicked(list[position])
        }
        h.b.bar.renderData(RallyVerticalBarData(100f, 100f, list[position].getColor()))

    }

    private fun getRemaining(p: Int, b: ItemBudgetBinding) {

        val myDb: MyDatabase? = MyDatabase.getInstance(c.applicationContext)
        var expense = myDb?.expenseDao()?.getTotalAmountInCategory(list[p].categoryId)
        if (expense == null)
            expense = 0
        val remaining = list[p].amount - expense
        b.tvLeft.text = if (remaining < 0) {
            "$${((remaining * -1).toString())}"
        } else {
            remaining.toString()
        }
        if (remaining < 0) {
            b.ivArrow.text = "Over"
        } else {

            b.ivArrow.text = "Left"
        }

        param.gotResults(list[p].categoryId, remaining)
    }

    private fun getCategoryName(position: Int, b: ItemBudgetBinding) {
        val myDb: MyDatabase? = MyDatabase.getInstance(c.applicationContext)
        val category = myDb?.categoryDao()?.getCategory(list[position].categoryId)
        b.tvName.text = category?.name
        Log.e(TAG, "getCategoryName: ${category?.name}")
    }

    override fun getItemCount(): Int {
//        Log.e(TAG, "getItemCount: "+list.size )
        return if (isDasBoard) {
            if (list.size > 2) {
                3
            } else {
                list.size
            }
        } else {
            list.size
        }
    }
}


class BudgetViewHolder(v: ItemBudgetBinding) : RecyclerView.ViewHolder(v.root) {
    var b = v
}