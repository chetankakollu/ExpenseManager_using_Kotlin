package com.trichain.expensemanager.room.tables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import com.trichain.expensemanager.R
import java.io.Serializable

@Entity(indices = [Index(value = ["name"], unique = true)])
class CategoryTable:Serializable {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null


    @ColumnInfo(name = "name")
    lateinit var name: String

    var userId: Int = 0

    var description: String = ""

    constructor(name: String, userId: Int) {
        this.name = name
        this.userId = userId
    }

    constructor()


    fun getColor(): Int {
        val mColor = listOf<Int>(
            R.color.rally_dark_green,
            R.color.rally_green_500,
            R.color.rally_green_300,
            R.color.rally_dark_green,
            R.color.rally_green_700,
            R.color.rally_green_500,
            R.color.rally_green_300,
            R.color.rally_dark_green,
            R.color.rally_green_500,
            R.color.rally_green_300
        )
        return if (id != null) {
            mColor[(id!!.rem(10))]
        } else {
            mColor[(0..9).random()]
        }
    }
}