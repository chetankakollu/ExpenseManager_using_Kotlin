package com.trichain.expensemanager.room.tables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class NotificationTable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null

    lateinit var info: String

    var username: Int=0

    var categoryId: Int=0

    lateinit var mDate: String
}