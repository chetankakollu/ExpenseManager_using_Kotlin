package com.trichain.expensemanager.ui

import android.app.Application
import androidx.lifecycle.Observer
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable

/**
 * Created by Yoosin Paddy on 7/31/22.
 */
class ExpenseApp : Application() {
  override fun onCreate() {
    super.onCreate()
  }

}