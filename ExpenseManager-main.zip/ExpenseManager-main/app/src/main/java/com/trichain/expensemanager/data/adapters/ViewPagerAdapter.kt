package com.trichain.expensemanager.ui

import android.util.Log
import androidx.annotation.DrawableRes
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import com.trichain.expensemanager.R
import com.trichain.expensemanager.ui.account.AccountFragment
import com.trichain.expensemanager.ui.expense.ExpenseFragment
import com.trichain.expensemanager.ui.budget.BudgetFragment
import com.trichain.expensemanager.ui.overview.OverviewFragment
import com.trichain.expensemanager.ui.settings.SettingsFragment

/**
 * Created by Yoosin Paddy on 7/30/22.
 */
class RallyPagerAdapter(
  fm: FragmentManager,
  private val tabs: List<TabUiModel>
) : FragmentStatePagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
    private val TAG = "ViewPagerAdapter"
  override fun getItem(position: Int): Fragment {
      Log.e(TAG, "getItem: $position", )
    return when (position) {
      0 -> OverviewFragment()
      1 -> AccountFragment()
      2 -> ExpenseFragment()
      3 -> BudgetFragment()
      4 -> SettingsFragment()
      else -> OverviewFragment()
    }
  }

  override fun getCount(): Int {

    return tabs.size
  }

}

fun generateTabs(): List<TabUiModel> {
  return listOf(
      TabUiModel("Overview", R.drawable.ic_overview),
      TabUiModel("Accounts", R.drawable.ic_attach_money),
      TabUiModel("Expense", R.drawable.ic_money_off),
      TabUiModel("Budget", R.drawable.ic_budget),
      TabUiModel("Setting", R.drawable.ic_settings)
  )
}

data class TabUiModel(val name: String, @DrawableRes val icon: Int)