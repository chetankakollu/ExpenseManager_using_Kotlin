package com.trichain.expensemanager.room.tables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class IncomeTable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null

    var userId: Int=0

    var amount: Int=0

    lateinit var mDate: String//YYYY-MM-dd
}