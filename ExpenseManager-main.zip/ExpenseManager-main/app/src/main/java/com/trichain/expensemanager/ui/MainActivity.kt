package com.trichain.expensemanager.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.trichain.expensemanager.R
import com.trichain.expensemanager.databinding.ActivityMainBinding
import com.trichain.expensemanager.room.tables.BudgetTable

//import kotlinx.android.synthetic.main.activity_main.tab_layout
//import kotlinx.android.synthetic.main.activity_main.view_pager

class MainActivity : AppCompatActivity() {
lateinit var b: ActivityMainBinding
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    b=DataBindingUtil.setContentView(this,R.layout.activity_main)

    if (savedInstanceState == null) runEnterAnimation()
    setUpViewPager()
  }

  private fun setUpViewPager() {
    val tabs = generateTabs()
    b.viewPager.adapter = RallyPagerAdapter(supportFragmentManager, tabs)
    b.viewPager.offscreenPageLimit = 0
    b.tabLayout.setUpWithViewPager(b.viewPager, false)

    b.viewPager.setCurrentItem(0, true)
  }

  fun navigateToTabs(item: TabItem) {
    b.viewPager.setCurrentItem(item.position, true)
  }
  fun navigateToTabs(item: TabItem,budgetTable: BudgetTable) {
    b.viewPager.setCurrentItem(item.position, true)
  }

  private fun runEnterAnimation() {
    b.tabLayout.post {
      b.tabLayout.translationY -= b.tabLayout.height.toFloat()
      b.tabLayout.alpha = 0f
      b.tabLayout.animate()
          .translationY(0f)
          .setInterpolator(AccelerateDecelerateInterpolator())
          .alpha(1f)
          .setDuration(300)
          .start()
    }
  }

  override fun onBackPressed() {
    if (b.viewPager.currentItem != 0) {
      b.viewPager.currentItem = 0
      return
    }
    super.onBackPressed()
  }

  companion object {
    fun start(context: Context) {
      val intent = Intent(context, MainActivity::class.java)
      //intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
      context.startActivity(intent)
    }
  }
}

enum class TabItem(val position: Int) {
  ACCOUNT(1),
  BILL(2),
  BUDGET(3)
}
