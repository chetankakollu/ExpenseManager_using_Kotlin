package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.IGNORE
import androidx.room.OnConflictStrategy.REPLACE
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.CategoryTable

@Dao
interface BudgetDao {
    @Insert(onConflict = REPLACE)
    fun insert(data: BudgetTable)

    @Delete
    fun delete(data: BudgetTable)

    @Update
    fun update(data: BudgetTable): Int

    @Query("SELECT * from BudgetTable ORDER BY id ASC")
    fun getAll(): List<BudgetTable>

    @Query("SELECT * from BudgetTable where mDate like:yyyy_MM ORDER BY id ASC")
    fun getSpecificPeriod(yyyy_MM:String): List<BudgetTable>

    @Query("SELECT * from BudgetTable where mDate like:yyyy_MM and categoryId=:catId and period=:period ORDER BY id DESC limit 1")
    fun getOneSpecificPeriod(yyyy_MM:String,catId:Int,period:String): BudgetTable

    @Query("SELECT amount from BudgetTable where mDate like :yyyy_MM and categoryId=:catId and period=:period ORDER BY id DESC limit 1")
    fun getSumForOneSpecificPeriod(yyyy_MM:String,catId:Int,period:String): Int


    @Query("SELECT * from BudgetTable ORDER BY id ASC")
    fun getAllL(): LiveData<List<BudgetTable>>

    @Query("SELECT * FROM BudgetTable WHERE id = :id LIMIT 1")
    fun getNote(id: Int): BudgetTable

    @Query("DELETE FROM BudgetTable")
    fun deleteAll(): Int
}