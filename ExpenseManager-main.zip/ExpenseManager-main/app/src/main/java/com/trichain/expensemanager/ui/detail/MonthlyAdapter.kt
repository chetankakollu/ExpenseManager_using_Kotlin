package com.trichain.expensemanager.ui.detail

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.model.ItemType.INCREASE
import com.trichain.expensemanager.data.model.MonthlyItem
import com.trichain.expensemanager.extension.inflate
import com.trichain.expensemanager.extension.toMoneyFormatted
import com.trichain.expensemanager.room.tables.ExpenseTable

/**
 * Created by Yoosin Paddy on 8/28/22.
 */
class MonthlyAdapter(private val items: List<ExpenseTable>) : RecyclerView.Adapter<MonthlyItemViewHolder>() {

  override fun getItemCount() = items.size

  override fun onCreateViewHolder(
    parent: ViewGroup,
    viewType: Int
  ): MonthlyItemViewHolder {
    return MonthlyItemViewHolder(parent.inflate(R.layout.item_monthly))
  }

  override fun onBindViewHolder(
    holder: MonthlyItemViewHolder,
    position: Int
  ) {
    holder.bind(items[position])
  }
}

class MonthlyItemViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

  private val tvName: TextView = view.findViewById(R.id.tvName)
  private val tvAmount: TextView = view.findViewById(R.id.tvAmount)
  private val tvViewDollar: TextView = view.findViewById(R.id.text_view_dollar)
  private val tvDate: TextView = view.findViewById(R.id.tvDate)

  fun bind(model: ExpenseTable) {
    tvName.text = model.name
    tvAmount.text = model.amount.toString()
    tvDate.text = model.mDate

    tvViewDollar.text = if (model.amount <0) {
      "-$"
    } else {
      "+$"
    }
  }
}