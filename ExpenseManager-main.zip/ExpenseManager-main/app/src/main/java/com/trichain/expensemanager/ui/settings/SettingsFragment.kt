package com.trichain.expensemanager.ui.settings

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.google.android.material.snackbar.Snackbar
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.Authenticator
import com.trichain.expensemanager.data.SharedPrefsManager
import com.trichain.expensemanager.databinding.DialogAddIncomeBinding
import com.trichain.expensemanager.databinding.FragmentSettingsBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.ui.auth.LoginActivity
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

/**
 * Created by lin min phyo on 2019-08-01.
 */
class SettingsFragment : Fragment() {
  lateinit var b:FragmentSettingsBinding
  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    b= FragmentSettingsBinding.inflate(inflater,container,false)
    return b.root
  }

  override fun onViewCreated(
    view: View,
    savedInstanceState: Bundle?
  ) {
    super.onViewCreated(view, savedInstanceState)

    b.imageEditCategory.setOnClickListener{
      startEditActivity()
    }
    b.tvEditCategory.setOnClickListener{
      startEditActivity()
    }
    setUpAmount()
    setUpAccount()

  }

  private fun setUpAccount() {
    b.editProfileConstrain.visibility=View.GONE
    b.btnLogout.setOnClickListener {
      Authenticator(requireContext()).logOut()
      requireContext().startActivity(Intent(requireActivity(),LoginActivity::class.java))
      requireActivity().finish()
    }
    b.imageEditProfile.setOnClickListener {
      b.editProfileConstrain.visibility=View.VISIBLE
      b.nameEd.requestFocus()
    }
    val userId=SharedPrefsManager.getInstance(requireContext())?.getUserId()
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
    if (myDb?.userDao()?.getUser(userId!!) != null) {
      val user=myDb?.userDao()?.getUser(userId!!)
      b.nameTv.setText(user.name)
      b.nameEd.setText(user.name)
      b.emailEd.setText(user.username)
      b.emailTv.setText(user.username)
      b.btnSaveProfile.setOnClickListener {
        if (b.nameEd.text.toString().isEmpty()){
          b.nameIl.error="Please fill this"
          b.nameIl.requestFocus()
        }else if (b.emailEd.text.toString().isEmpty()){
          b.emailIl.error="Please fill this"
          b.emailIl.requestFocus()
        }else  if (b.curPassEd.text.toString().isEmpty()){
          b.curPassIl.error="Please fill this"
          b.curPassIl.requestFocus()
        }else  if (!b.curPassEd.text.toString().contentEquals(user.password)){
          b.curPassIl.error="Please password do not match"
          b.curPassIl.requestFocus()
        }else {
          if (b.newPassEd.text.toString().isNotEmpty()){
            user.password=b.newPassEd.text.toString()
          }
          user.name=b.nameEd.text.toString()
          user.username=b.emailEd.text.toString()

          CompositeDisposable().add(Observable.fromCallable { myDb?.userDao()?.update(user) }
            .subscribeOn(Schedulers.computation())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe {
              Log.d("respons", "user updated")
              Snackbar.make(b.viewProfileConstrain,"Profile Updated",Snackbar.LENGTH_LONG).show()
              setUpAccount()
            })
        }
      }
    }
  }

  private fun setUpAmount() {

    b.tvIncomeAmount.text="$${SharedPrefsManager.getInstance(requireContext())?.getUserIncome().toString()}"
    b.imageEditIncome.setOnClickListener {
      val dialog = Dialog(requireContext(), R.style.Widget_Rally_AlertDialog).apply {
        setCancelable(true)
        val view = DialogAddIncomeBinding.inflate(LayoutInflater.from(requireContext()))
        setContentView(view.root)

        val width = if (resources.configuration.smallestScreenWidthDp >= 600) {
          resources.displayMetrics.widthPixels * 0.65
        } else {
          resources.displayMetrics.widthPixels * 0.8
        }

        window?.setLayout(width.toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)

        if (SharedPrefsManager.getInstance(requireContext())?.getUserIncome()!=0){
          view.editAMount.setText("$${SharedPrefsManager.getInstance(requireContext())?.getUserIncome()}")
        }

        view.btnDismiss.setOnClickListener {
          if (view.editAMount.text.toString().isEmpty()) {
            view.amountIL.error = "Please fill this"
            view.editAMount.requestFocus()
          }  else {
            SharedPrefsManager.getInstance(requireContext())?.setUserIncome(view.editAMount.text.toString().toInt())
            dismiss()
            setUpAmount()
          }
        }

      }

      dialog.show()
    }
  }

  private fun startEditActivity() {
    requireActivity().startActivity(Intent(requireActivity(),EditCategoriesActivity::class.java))
  }
}