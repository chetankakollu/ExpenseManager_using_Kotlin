package com.trichain.expensemanager.data.model

import androidx.annotation.DrawableRes

/**
 * Created by lin min phyo on 2019-08-24.
 */
data class Alert(val alert : String , @DrawableRes val drawableRes: Int)