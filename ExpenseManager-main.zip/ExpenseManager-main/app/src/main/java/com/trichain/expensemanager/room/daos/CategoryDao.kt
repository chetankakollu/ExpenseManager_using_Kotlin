package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.IGNORE
import com.trichain.expensemanager.room.tables.CategoryTable

@Dao
interface CategoryDao {
    @Insert(onConflict = IGNORE)
    fun insert(data: CategoryTable)

    @Delete
    fun delete(data: CategoryTable)

    @Update
    fun update(data: CategoryTable): Int

    @Query("SELECT * from CategoryTable ORDER BY id ASC")
    fun getAll(): List<CategoryTable>


    @Query("SELECT * from CategoryTable ORDER BY id ASC")
    fun getAllL(): LiveData<List<CategoryTable>>

    @Query("SELECT * FROM CategoryTable WHERE id = :id LIMIT 1")
    fun getCategory(id: Int): CategoryTable

    @Query("DELETE FROM CategoryTable")
    fun deleteAll(): Int
}