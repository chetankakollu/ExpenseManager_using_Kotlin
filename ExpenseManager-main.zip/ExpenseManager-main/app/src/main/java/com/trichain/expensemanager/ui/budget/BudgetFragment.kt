package com.trichain.expensemanager.ui.budget

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.SharedPrefsManager
import com.trichain.expensemanager.databinding.DialogAddBudgetBinding
import com.trichain.expensemanager.databinding.FragmentBudgetBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.ui.info.InfoFragment
import com.trichain.expensemanager.ui.overview.adapter.BudgetAdapter
import com.trichain.rally_pie.RallyPieAnimation
import com.trichain.rally_pie.RallyPieData
import com.trichain.rally_pie.RallyPiePortion
import com.trichain.rally_pie.pxToDp
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*


/**
 * Created by Yoosin Paddy on 8/13/22.
 */
class BudgetFragment : Fragment() {

    private lateinit var budgetAdapter: BudgetAdapter
    private lateinit var budgetList: List<BudgetTable>
    lateinit var b: FragmentBudgetBinding
    lateinit var categoryList: List<CategoryTable>
    private val TAG = "BudgetFragment"
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        b = FragmentBudgetBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        b.btnInfo.setOnClickListener {
            val infoFragment = InfoFragment()
            infoFragment.show(childFragmentManager, "AccountInfo")
        }
    }

    override fun onResume() {
        super.onResume()
        setUpRecyclerView()
        b.addFab?.setOnClickListener {
            var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
                "0"
            }else{
                ""
            }
            var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
                "0"
            }else{
                ""
            }
            addBudget(
                BudgetTable(
                    "${Calendar.getInstance().get(Calendar.YEAR)
                    }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)
                    }-$dayPref${Calendar.getInstance().get(Calendar.DATE)}"
                )
            )
        }
    }

    private fun addBudget(itemBudget: BudgetTable) {

        var item = itemBudget
        Log.e(TAG, "addBudget: ${item.toString()}")
        if (item.categoryId != 0) {

            val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())
            val cat =
                myDb?.budgetDao()?.getOneSpecificPeriod(item.mDate, item.categoryId, item.period!!)
            if (cat != null) {
                item = cat
            } else {
                Log.e(TAG, "addBudget: cat is null")
            }
        } else {
            Log.e(TAG, "addBudget: categoryid=0")
        }
        val dialog = Dialog(requireContext(), R.style.Widget_Rally_AlertDialog).apply {
            setCancelable(true)
            val view = DialogAddBudgetBinding.inflate(LayoutInflater.from(requireContext()))
            setContentView(view.root)

            val width = if (resources.configuration.smallestScreenWidthDp >= 600) {
                resources.displayMetrics.widthPixels * 0.65
            } else {
                resources.displayMetrics.widthPixels * 0.8
            }

            window?.setLayout(width.toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
            val categories = getMyCategories()

            val arraySpinner = categories.map { it.name }.toTypedArray()
            val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
                requireContext(),
                android.R.layout.simple_spinner_item, arraySpinner
            )
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            view.categorySpinner.setAdapter(adapter)
            if (item.categoryId != 0) {
                categories.forEachIndexed { p, it ->
                    if (it.id == item.id) {
                        view.categorySpinner.setSelection(p)
                    }
                }
            }
            if (item.amount != 0) {
                view.editAMount.setText(item.amount.toString())
            }
            if (item.period != null) {
                requireContext().resources.getStringArray(R.array.budget_type)
                    .forEachIndexed { p, it ->
                        if (it == item.period) {
                            view.typeSpinner.setSelection(p)
                        }
                    }
            }
            view.btnDismiss.setOnClickListener {
                if (view.editAMount.text.toString().isEmpty()) {
                    view.amountIL.error = "Please fill this"
                    view.editAMount.requestFocus()
                } else {
                    var carId = 0
                    categories.forEach {
                        if (it.name.contentEquals(view.categorySpinner.selectedItem as String)) {
                            carId = it.id!!
                        }
                    }
                    Log.e(TAG, "addBudget: "+view.typeSpinner.selectedItem.toString() )
                    Log.e(TAG, "addBudget: "+view.typeSpinner.selectedItemPosition )
                    item.categoryId = carId
                    item.amount = view.editAMount.text.toString().toInt()
                    item.period = view.typeSpinner.selectedItem.toString()
                    item.userId = SharedPrefsManager.getInstance(requireContext())?.getUserId()!!
                    insert(item)
                    dismiss()
                }
            }

        }

        dialog.show()
    }

    fun insert(mItem: BudgetTable) {
        var item = mItem
        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())
        val cat =
            myDb?.budgetDao()?.getOneSpecificPeriod(item.mDate, item.categoryId, item.period!!)
        if (cat != null) {
            item.id = cat.id
        } else {
            Log.e(TAG, "addBudget: cat is null")
        }
        Log.e(TAG, "insert: ${item.toString()}", )

        CompositeDisposable().add(Observable.fromCallable { myDb?.budgetDao()?.insert(item) }
            .subscribeOn(Schedulers.computation())
            .observeOn(AndroidSchedulers.mainThread())
            .subscribe {
                Log.e(TAG, "data updated")
                setUpRecyclerView()
            })
    }

    private fun getMyCategories(): List<CategoryTable> {
//        if (categoryList==null||categoryList.size > 0) {
//            return categoryList
//        }
        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
        if (myDb?.categoryDao()?.getAll() != null) {
            categoryList = myDb?.categoryDao()?.getAll()
        } // get All data
        if (categoryList == null)
            categoryList = ArrayList<CategoryTable>()
        return categoryList

    }

    private fun setUpPieView() {
//        b.tvAmount.text = DataProvider.budgetOverView.budgets.sumByDouble { it.spend.toDouble() }
//            .toFloat()
//            .toUSDFormatted()
        val rallyPiePortions = budgetList.map {
            RallyPiePortion(
                getCategoryName(it.categoryId),
                getSpent(it).toFloat(),
                ContextCompat.getColor(requireContext(), it.getColor())
            )
        }

        val rallyPieData = RallyPieData(
            portions = rallyPiePortions,
            maxValue = budgetList.sumOf { budgetTable: BudgetTable -> budgetTable.amount }.toFloat()
        )

        Log.e(TAG, "setUpPieView-portions: ${rallyPiePortions.size}")
        Log.e(
            TAG,
            "setUpPieView-maxValue: ${
                budgetList.sumOf { budgetTable: BudgetTable -> budgetTable.amount }.toFloat()
            }",
        )
        val rallyPieAnimation = RallyPieAnimation(b.rallyPie)
        rallyPieAnimation.duration = 600

        b.rallyPie.setPieData(pieData = rallyPieData, animation = rallyPieAnimation)
    }

    private fun getCategoryName(catId: Int): String {
        var name: String = ""
        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext().applicationContext)
        val category = myDb?.categoryDao()?.getCategory(catId)
        if (category?.name != null)
            name = category.name

        return name

    }

    private fun getSpent(budget: BudgetTable): Int {

        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext().applicationContext)
        var expense = myDb?.expenseDao()?.getTotalAmountInCategory(budget.categoryId)
        if (expense == null)
            expense = 0
//        val remaining = budget.amount - expense
        return expense
    }

    private fun setUpRecyclerView() {
        budgetList = getMyBudgetList()
        budgetLeft = HashMap<Int, Int>()
        Log.i("Width", requireContext().pxToDp(requireView().measuredWidth).toString())
        budgetAdapter =
            BudgetAdapter(requireActivity(), budgetList, false, object : OnBudgetUpdated {
                override fun gotResults(catId: Int, amountLeft: Int) {
                    calculateBudgetLeft(catId, amountLeft)
                }

                override fun budgetClicked(budgetTable: BudgetTable) {
                    addBudget(budgetTable)
                }
            })

        b.rvBudget.apply {
            layoutManager = LinearLayoutManager(requireContext())
            setHasFixedSize(true)
            addItemDecoration(getRallyItemDecoration())
            adapter = budgetAdapter
        }
//    budgetAdapter.submitList(DataProvider.budgetOverView.budgets)

        if (budgetList.size == 0) {
            b.labelAlert.visibility = View.GONE
            b.tvAmount.visibility = View.GONE
            b.btnInfo.visibility = View.GONE
            b.rallyPie.visibility = View.GONE
            b.rallyPie.visibility = View.GONE
            b.noExpenseTv?.visibility = View.VISIBLE
            b.addFab?.performClick()
        } else {

            b.labelAlert.visibility = View.VISIBLE
            b.tvAmount.visibility = View.VISIBLE
            b.btnInfo.visibility = View.VISIBLE
            b.rallyPie.visibility = View.VISIBLE
            b.rallyPie.visibility = View.VISIBLE
            b.noExpenseTv?.visibility = View.GONE
        }

        setUpPieView()
    }

    var budgetLeft = HashMap<Int, Int>()
    private fun calculateBudgetLeft(catId: Int, amountLeft: Int) {
        Log.e(TAG, "calculateBudgetLeft: ${budgetLeft.toString()}")
        budgetLeft.put(catId, amountLeft)
        var totalLeft: Int = 0
        budgetLeft.forEach {
            totalLeft += it.value
        }
        if (totalLeft < 0) {
            b.tvAmount.text = (totalLeft * -1).toString()
            b.labelAlert.text = "Overspent"
        } else {
            b.tvAmount.text = (totalLeft).toString()
            b.labelAlert.text = "Left"
        }
        Log.e(TAG, "calculateBudgetLeftA: ${budgetLeft.toString()}")
    }

    private fun getMyBudgetList(): List<BudgetTable> {

        var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
            "0"
        }else{
            ""
        }
        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
        var listBudgets = myDb?.budgetDao()?.getSpecificPeriod(
            "${
                Calendar.getInstance().get(Calendar.YEAR)
            }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)}%"
        ) // get All data
        if (listBudgets == null)
            listBudgets = ArrayList<BudgetTable>()
        Log.e(TAG, "getMyBudgetList: ${listBudgets.size}")
        return listBudgets
    }

    interface OnBudgetUpdated {
        fun gotResults(catId: Int, amountLeft: Int)
        fun budgetClicked(budgetTable: BudgetTable)
    }
}
