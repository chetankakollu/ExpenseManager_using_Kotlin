package com.trichain.expensemanager.data

import android.content.Context
import android.util.Log
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.UserTable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

/**
 * Created by Yoosin Paddy on 8/26/22.
 */
class Authenticator(val context: Context) {

  private val pref = context.getSharedPreferences("FinanceApp", Context.MODE_PRIVATE)
  val db: MyDatabase? = MyDatabase.getInstance(context) // call database

  fun isLoggedIn(): Boolean {
    return pref.getBoolean(KEY_LOGIN, false)
  }
  fun logOut() {
    pref.edit().putBoolean(KEY_LOGIN, false).apply()
  }

  fun login(
    email: String,
    password: String
  ): Boolean {
    val user:UserTable?=db?.userDao()?.logUserIn(email,password)
    if (user==null)(
            return false
    )else{
      pref.edit()
        .putBoolean(KEY_LOGIN, true)
        .putString(KEY_USER_EMAIL,user.username)
        .putString(KEY_USER_NAME,user.name)
        .putInt(KEY_USER_ID, user.id!!)
        .apply()
      return true
    }
  }

  fun register(name: String, email: String, password: String): Boolean {

    val user = UserTable() //create new note
    user.name = name
    user.username = email
    user.password = password

    CompositeDisposable().add(Observable.fromCallable { db?.userDao()?.insert(user) }
      .subscribeOn(Schedulers.computation())
      .observeOn(AndroidSchedulers.mainThread())
      .subscribe {
        Log.d("respons", "user inserted")
      })
    return true
  }

  companion object {
    private const val KEY_LOGIN = "key-login"
    private const val KEY_USER_ID = "key_user_id"
    private const val KEY_USER_EMAIL = "key_user_email"
    private const val KEY_USER_NAME = "key_user_name"
  }
}