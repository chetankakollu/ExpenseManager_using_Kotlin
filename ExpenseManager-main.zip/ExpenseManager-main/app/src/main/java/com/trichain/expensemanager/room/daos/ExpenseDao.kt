package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable

@Dao
interface ExpenseDao {
    @Insert(onConflict = REPLACE)
    fun insert(data: ExpenseTable)

    @Delete
    fun delete(data: ExpenseTable)

    @Update
    fun update(data: ExpenseTable): Int

    @Query("SELECT * from ExpenseTable ORDER BY id ASC")
    fun getAll(): List<ExpenseTable>

    @Query("SELECT sum(amount) from ExpenseTable where categoryId=:catId and mDate like :date")
    fun getSumByMonth(date:String,catId:Int): Int

    @Query("SELECT * from ExpenseTable where categoryId=:catId and mDate like :date")
    fun getListByMonth(date:String,catId:Int): List<ExpenseTable>

    @Query("SELECT sum(amount) from ExpenseTable where categoryId=:catId")
    fun getTotalAmountInCategory(catId:Int): Int


    @Query("SELECT * from ExpenseTable ORDER BY id DESC")
    fun getAllL(): LiveData<List<ExpenseTable>>

    @Query("SELECT * FROM ExpenseTable WHERE id = :id LIMIT 1")
    fun getNote(id: Int): ExpenseTable

    @Query("DELETE FROM ExpenseTable")
    fun deleteAll(): Int
}