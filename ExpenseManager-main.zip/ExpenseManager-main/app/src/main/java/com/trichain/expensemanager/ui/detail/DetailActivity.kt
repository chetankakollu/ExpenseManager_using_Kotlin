package com.trichain.expensemanager.ui.detail

//import com.trichain.expensemanager.R.id
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityOptionsCompat
import androidx.core.util.Pair
import androidx.databinding.DataBindingUtil
import com.trichain.expensemanager.R
import com.trichain.expensemanager.databinding.ActivityDetailBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.rally_line_chart.DataPoint
import java.text.Format
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class DetailActivity : AppCompatActivity() {
    lateinit var b: ActivityDetailBinding
    lateinit var categoryTable: CategoryTable
    private val TAG = "DetailActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = DataBindingUtil.setContentView(this, R.layout.activity_detail)
        categoryTable = intent.getSerializableExtra("category") as CategoryTable
        b.rallyLine.setCurveBorderColor(intent.getIntExtra(KEY_COLOR, R.color.rally_dark_green))
        Log.e(TAG, "onCreate: ${categoryTable.id}", )
        setUpToolbar()
        setUpTab()
        b.rallyLine.addDataPoints(getPoints(0))
    }


    private fun setUpToolbar() {
        setSupportActionBar(b.toolbar.toolbar as Toolbar?)
        b.toolbar.toolbar.title= categoryTable.name
        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.title = categoryTable.name
    }

    private fun setUpTab() {
        val strMonth: String = f.format(Date())
        b.tab.addTabs(
            getNestTab(1, listOf("$strMonth ${Calendar.getInstance().get(Calendar.YEAR)}"))
        )
        b.tab.addOnPageChangeListener {
            b.rallyLine.addDataPoints(getPoints(it))
        }

        b.viewPager.adapter = MonthlyPagerAdapter(supportFragmentManager,categoryTable)
        b.tab.setUpWithViewPager(b.viewPager)
    }

    val f: Format = SimpleDateFormat("MMM")
    private fun getNestTab(p: Int, list: List<String>): List<String> {
        if (p == 10) {
            return list
        } else {
            var c = Calendar.getInstance()
            c.set(Calendar.DAY_OF_MONTH, 1)
            c.add(Calendar.MONTH, (-1 * p))
            val strMonth: String = f.format(c.time)
            var m = ArrayList(list)
            m.add("$strMonth ${c.get(Calendar.YEAR)}")
            return getNestTab(p + 1, m)

        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_detail, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            super.onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        private const val KEY_COLOR = "key-color"
        fun start(
            context: Context,
            shareView: View, categoryTable: CategoryTable
        ) {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra(KEY_COLOR, categoryTable.getColor())
            intent.putExtra("category", categoryTable)

            val pair = Pair(shareView.findViewById<View>(R.id.shareView), "DetailView")
            val options =
                ActivityOptionsCompat.makeSceneTransitionAnimation(
                    context as AppCompatActivity,
                    pair
                )

            val transition = context.window.exitTransition
            transition.excludeTarget(shareView, true)
            context.window.exitTransition = transition

            context.startActivity(intent, options.toBundle())
        }
    }

    fun getPoints(p: Int): MutableList<DataPoint> {
        val list = mutableListOf<DataPoint>()

        var c = Calendar.getInstance()
        c.set(Calendar.DAY_OF_MONTH, 1)
        var l = Calendar.getInstance()
        l.add(Calendar.MONTH, 1)
        l.set(Calendar.DAY_OF_MONTH, 1)
        l.add(Calendar.DAY_OF_MONTH, -1)
        if (p != 0) {
            c.add(Calendar.MONTH, (-1 * p))
        }
//        Log.e(TAG, "getPoints-day: ${c.get(Calendar.DAY_OF_MONTH)}", )
//        Log.e(TAG, "getPoints-month: ${c.get(Calendar.DAY_OF_MONTH)}", )
//        val range = (0..10)
        val daysRange = (c.get(Calendar.DAY_OF_MONTH)..l.get(Calendar.DAY_OF_MONTH))

//        (1..15).forEach { _ ->
//            list.add(DataPoint(range.random() * 100f))
//        }
        daysRange.forEach { d ->
            run {
                c.set(Calendar.DAY_OF_MONTH, d)
                var n = c
                list.add(DataPoint(getDataFor(n)))
            }
        }
        Log.e(TAG, "getPoints: ${list.toString()}", )
        return list
    }

    fun getDataFor(n: Calendar): Float {
        var monthPref = if ((n.get(Calendar.MONTH) + 1) < 10) {
            "0"
        } else {
            ""
        }
        var dayPref = if (n.get(Calendar.DATE) < 10) {
            "0"
        } else {
            ""
        }
        var thisDay = "${
            n.get(Calendar.YEAR)
        }-$monthPref${
            (n.get(Calendar.MONTH) + 1)
        }-$dayPref${
            (n.get(Calendar.DAY_OF_MONTH))
        }"
        Log.e(TAG, "getDataFor: $thisDay", )
        val myDb: MyDatabase? = MyDatabase.getInstance(this)
        var mSum = myDb?.expenseDao()?.getSumByMonth(thisDay, categoryTable.id!!)
        if (mSum == null)
            mSum = 0
        return mSum.toFloat()
    }
}


