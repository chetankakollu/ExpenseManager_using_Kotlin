package com.trichain.expensemanager.ui.detail

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.trichain.expensemanager.room.tables.CategoryTable

/**
 * Created by Yoosin Paddy on 8/4/22.
 */
class MonthlyPagerAdapter(fm: FragmentManager, val categoryTable: CategoryTable) : FragmentPagerAdapter(
    fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT
) {
  override fun getItem(position: Int): Fragment {
    return MonthlyFragment.newInstance(position,categoryTable)
  }

  override fun getCount(): Int {
    return 12
  }
}