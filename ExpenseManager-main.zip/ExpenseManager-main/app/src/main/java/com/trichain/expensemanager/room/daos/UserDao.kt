package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.trichain.expensemanager.room.tables.*

@Dao
interface UserDao {
    @Insert(onConflict = REPLACE)
    fun insert(data: UserTable)

    @Delete
    fun delete(data: UserTable)

    @Update
    fun update(data: UserTable): Int

    @Query("SELECT * from UserTable ORDER BY id ASC")
    fun getAll(): List<UserTable>

    @Query("SELECT * from UserTable where username=:email and password=:pass limit 1")
    fun logUserIn(email:String,pass:String): UserTable


    @Query("SELECT * from UserTable ORDER BY id ASC")
    fun getAllL(): LiveData<List<UserTable>>

    @Query("SELECT * FROM UserTable WHERE id = :id LIMIT 1")
    fun getUser(id: Int): UserTable

    @Query("DELETE FROM UserTable")
    fun deleteAll(): Int
}