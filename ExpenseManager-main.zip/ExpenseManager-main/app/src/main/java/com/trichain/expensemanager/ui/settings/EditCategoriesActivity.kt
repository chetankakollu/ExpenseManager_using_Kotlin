package com.trichain.expensemanager.ui.settings

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.SharedPrefsManager
import com.trichain.expensemanager.data.adapters.CategorySettingsAdapter
import com.trichain.expensemanager.databinding.ActivityEditCategoriesBinding
import com.trichain.expensemanager.databinding.DialogEditCategoryBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class EditCategoriesActivity : AppCompatActivity() {
    lateinit var b:ActivityEditCategoriesBinding
    lateinit var adapter:CategorySettingsAdapter
    var categories: List<CategoryTable> = ArrayList()
    private  val TAG = "EditCategoriesActivity"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b=DataBindingUtil.setContentView(this,R.layout.activity_edit_categories)
        getCategories()


    }
    private fun saveCategory(note: CategoryTable) {

        val myDb: MyDatabase? = MyDatabase.getInstance(this) //

        CompositeDisposable().add(
            Observable.fromCallable {
                if (note != null) {
                    myDb?.categoryDao()?.insert(note)
                }
            }.subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    Log.d("respons", "data Inserted")
                })
    }
    private fun getCategories() {

        val myDb: MyDatabase? = MyDatabase.getInstance(this) // call database
        val listCategories = myDb?.categoryDao()?.getAllL() // get All data
        if (listCategories != null) {
            listCategories.observe(this, Observer {
                adapter= CategorySettingsAdapter(this,it)
                b.categoriesRv.adapter=adapter
                b.categoriesRv.layoutManager=LinearLayoutManager(this)
                b.addBtn.setOnClickListener {

                    var a = AlertDialog.Builder(this)
                    var v = DialogEditCategoryBinding.inflate(LayoutInflater.from(this))
                    a.setView(v.root)
                    var t=a.create()
                    v.btnDismiss.setOnClickListener {
                        if (v.editCategory.text.isNullOrEmpty()) {
                            v.editCategory.setError("Please fill this")
                            v.editCategory.requestFocus()
                        } else {
                            var mCategory=CategoryTable(v.editCategory.text.toString(),
                                SharedPrefsManager.getInstance(this)?.getUserId()!!
                            )
                            saveCategory(mCategory.apply {
                                name = v.editCategory.text.toString()
                            })
                            t.dismiss()
                        }
                    }
                    t.show()
                }
                Log.e(TAG, "getCategories: "+it.size )
//                categories= ArrayList()
//                adapter.notifyDataSetChanged()
            })
        }
    }
}