package com.trichain.expensemanager.data

import android.content.Context
import android.content.SharedPreferences
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*

class SharedPrefsManager private constructor(context: Context) {
    private val KEY_USER_ID: String="key_user_id"
    private val KEY_USER_INCOME: String="key_user_income"
    private val SHARED_PREFS_NAME = "expense_share_pref"

    /*Check if user is registered*/
    val isRegistered: Boolean
        get() = sharedPreferences.getBoolean(KEY_IS_USER_REGISTERED, false)

    /*check if user as enrolled to leaderboard*/
    fun hasEnrolledToLeaderBoard(): Boolean {
        return sharedPreferences.getBoolean(KEY_IS_ENROLLED, false)
    }

    fun getUserId():Int{
        return  sharedPreferences.getInt(KEY_USER_ID,1)
    }
    fun getUserIncome():Int{
        return  sharedPreferences.getInt(KEY_USER_INCOME,0)
    }
    fun setUserIncome(amount: Int) {
        return  sharedPreferences.edit().putInt(KEY_USER_INCOME,amount).apply()
    }

    /*enroll to leaderboard*/
    fun enrollUserToLeaderBoard() {
        sharedPreferences.edit().putBoolean(KEY_IS_ENROLLED, true).apply()
    }

    /*unenroll from leaderboard*/
    fun unEnrollUserToLeaderBoard() {
        sharedPreferences.edit().putBoolean(KEY_IS_ENROLLED, false).apply()
    }

    /*Check if user has accepted terms*/
    fun hasAcceptedTerms(): Boolean {
        return sharedPreferences.getBoolean(KEY_HAS_ACCEPTED_TERMS, false)
    }

    /*Set user has accepted terms*/
    fun setAcceptedTerms(accepted: Boolean) {
        sharedPreferences.edit()
            .putBoolean(KEY_HAS_ACCEPTED_TERMS, accepted)
            .apply()
    }

    /*Check if has shown notification today*/
    fun hasShownNotification(): Boolean {
        val c = Calendar.getInstance()
        val format: DateFormat = SimpleDateFormat("yyyyMMdd")
        val dateNow = format.format(c.time)
        return sharedPreferences.getString(KEY_NOTIFICATION_DATE, "dfsds").contentEquals(dateNow)
    }

    /*Set notification date*/
    fun setNotificationShown() {
        val c = Calendar.getInstance()
        val format: DateFormat = SimpleDateFormat("yyyyMMdd")
        val dateNow = format.format(c.time)
        sharedPreferences.edit()
            .putString(KEY_NOTIFICATION_DATE, dateNow)
            .apply()
    }

    companion object {
        private const val KEY_IS_USER_REGISTERED = "key_is_user_registered"
        private const val KEY_IS_ENROLLED = "key_has_enrolled_to_leaderboard"
        private const val KEY_HAS_ACCEPTED_TERMS = "key_has_accepted_terms"
        private const val KEY_NOTIFICATION_DATE = "key_notification_date"
        private lateinit var sharedPreferences: SharedPreferences
        private var mInstance: SharedPrefsManager? = null
        private const val TAG = "SharedPrefsManager"
        @Synchronized
        fun getInstance(context: Context): SharedPrefsManager? {
            if (mInstance == null) {
                mInstance = SharedPrefsManager(context)
            }
            return mInstance
        }
    }

    //toggle case Ctrl+Shift+U
    init {
        sharedPreferences = context.getSharedPreferences(SHARED_PREFS_NAME, Context.MODE_PRIVATE)
    }
}