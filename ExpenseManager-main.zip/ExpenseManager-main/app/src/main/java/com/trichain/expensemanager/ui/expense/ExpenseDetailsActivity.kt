package com.trichain.expensemanager.ui.expense

import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.SharedPrefsManager
import com.trichain.expensemanager.databinding.ActivityExpenseDetailsBinding
import com.trichain.expensemanager.databinding.DialogAddExpenseBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import com.trichain.expensemanager.ui.overview.adapter.ExpenseAdapter
import com.trichain.rally_pie.RallyPieAnimation
import com.trichain.rally_pie.RallyPieData
import com.trichain.rally_pie.RallyPiePortion
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.util.*

/**
 * Created by Yoosin Paddy on 8/13/22.
 */
class ExpenseDetailsActivity : AppCompatActivity() {
  private val TAG = "ExpenseFragment"
  lateinit var expenseList: List<ExpenseTable>

  lateinit var categoryList: List<CategoryTable>
  private lateinit var expenseAdapter :ExpenseAdapter
lateinit var b: ActivityExpenseDetailsBinding
  

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    b= DataBindingUtil.setContentView(this,R.layout.activity_expense_details)
  }

  

  override fun onResume() {
    super.onResume()
    setUpRecyclerView()
    b.addFab?.setOnClickListener {
      var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
        "0"
      }else{
        ""
      }
      var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
        "0"
      }else{
        ""
      }
      addExpense(
        ExpenseTable(
          "${Calendar.getInstance().get(Calendar.YEAR)
          }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)
          }-$dayPref${Calendar.getInstance().get(Calendar.DATE)}"
        )
      )
    }
  }

  private fun addExpense(expenseTable: ExpenseTable) {

    var item=expenseTable
//    Log.e(TAG, "addBudget: ${item.toString()}", )
//    if (item.categoryId!=0){
//
//      val myDb: MyDatabase? = MyDatabase.getInstance(this@ExpenseDetailsACtivity)
//      val cat = myDb?.expenseDao()?.getAll(item.mDate,item.categoryId,item.period!!)
//      if (cat!=null){
//        item=cat
//      }else{
//        Log.e(TAG, "addBudget: cat is null", )
//      }
//    }else{
//      Log.e(TAG, "addBudget: categoryid=0", )
//    }
    val dialog = Dialog(this, R.style.Widget_Rally_AlertDialog).apply {
      setCancelable(true)
      val view = DialogAddExpenseBinding.inflate(LayoutInflater.from(this@ExpenseDetailsActivity))
      setContentView(view.root)

      val width = if (resources.configuration.smallestScreenWidthDp >= 600) {
        resources.displayMetrics.widthPixels * 0.65
      } else {
        resources.displayMetrics.widthPixels * 0.8
      }

      window?.setLayout(width.toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
      val categories = getMyCategories()

      val arraySpinner = categories.map { it.name }.toTypedArray()
      val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
        this@ExpenseDetailsActivity,
        android.R.layout.simple_spinner_item, arraySpinner
      )
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
      view.categorySpinner.setAdapter(adapter)
      if (item.categoryId != 0) {
        categories.forEachIndexed { p, it ->
          if (it.id == item.id) {
            view.categorySpinner.setSelection(p)
          }
        }
      }
      if (item.amount != 0) {
        view.editAMount.setText(item.amount.toString())
      }

      view.btnDismiss.setOnClickListener {
        if (view.editAMount.text.toString().isEmpty()) {
          view.amountIL.error = "Please fill this"
          view.editAMount.requestFocus()
        } else if (view.nameEd.text.toString().isEmpty()) {
          view.nameIL.error = "Please fill this"
          view.editAMount.requestFocus()
        } else {
          var carId = 0
          categories.forEach {
            if (it.name.contentEquals(view.categorySpinner.selectedItem as String)) {
              carId = it.id!!
            }
          }
          item.categoryId = carId
          item.amount = view.editAMount.text.toString().toInt()
          item.name = view.nameEd.text.toString()
          item.userId = SharedPrefsManager.getInstance(this@ExpenseDetailsActivity)?.getUserId()!!

          insert(item)
          dismiss()
        }
      }

    }

    dialog.show()
  }

  fun insert(mItem: ExpenseTable) {
    Log.e(TAG, "insert: ${mItem.toString()}", )
    var item = mItem
    val myDb: MyDatabase? = MyDatabase.getInstance(this@ExpenseDetailsActivity)

    CompositeDisposable().add(Observable.fromCallable { myDb?.expenseDao()?.insert(item) }
      .subscribeOn(Schedulers.computation())
      .observeOn(AndroidSchedulers.mainThread())
      .subscribe {
        Log.e(TAG, "data updated")
        setUpRecyclerView()
      })
  }

  private fun getMyCategories(): List<CategoryTable> {
//        if (categoryList==null||categoryList.size > 0) {
//            return categoryList
//        }
    val myDb: MyDatabase? = MyDatabase.getInstance(this@ExpenseDetailsActivity) // call database
    if (myDb?.categoryDao()?.getAll() != null) {
      categoryList = myDb?.categoryDao()?.getAll()
    } // get All data
    if (categoryList == null)
      categoryList = ArrayList<CategoryTable>()
    return categoryList

  }
  private fun setUpPieView() {
    val rallyPiePortions = categoryList.map {
      RallyPiePortion(
          it.name, getExpenseAmountFromCategory(it).toFloat(), ContextCompat.getColor(this@ExpenseDetailsActivity, it.getColor())
      )
    }
        .toList()
    val rallyPieData = RallyPieData(portions = rallyPiePortions)
    val rallyPieAnimation = RallyPieAnimation(b.rallyPie).apply {
      duration = 600
    }


    b.rallyPie.setPieData(pieData = rallyPieData, animation = rallyPieAnimation)
  }

  private fun setUpRecyclerView() {
    val myDb: MyDatabase? = MyDatabase.getInstance(this@ExpenseDetailsActivity) // call database
    val listExpense = myDb?.categoryDao()?.getAllL() // get All data
    if (listExpense != null) {
      listExpense.observe(this, Observer {
        categoryList = it

//        expenseAdapter=  ExpenseAdapter(this@ExpenseDetailsActivity, categoryList, object: ExpenseFragment.OnExpenseUpdated {
//
//        })
//        b.rvBill.apply {
//          layoutManager = LinearLayoutManager(this@ExpenseDetailsActivity)
//          setHasFixedSize(true)
//          addItemDecoration(getRallyItemDecoration())
//          adapter = expenseAdapter
//        }
//        expenseAdapter.notifyDataSetChanged()
//        if (it.size == 0) {
//          b.rallyPie.visibility=View.GONE
//          b.noExpenseTv?.visibility  =View.VISIBLE
//          b.tvAmount?.visibility  =View.GONE
//          b.btnInfo?.visibility  =View.GONE
//        }else{
//          b.rallyPie.visibility=View.VISIBLE
//          b.tvAmount.visibility=View.VISIBLE
//          b.btnInfo.visibility=View.VISIBLE
//          b.noExpenseTv?.visibility=View.GONE
//          b.tvAmount.text=it.sumOf { e:CategoryTable->getExpenseAmountFromCategory(e) }.toString()
//        }
//        setUpPieView()
      })
    }

  }

  private fun getExpenseAmountFromCategory(model: CategoryTable) :Int{

    var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
      "0"
    }else{
      ""
    }
    var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
      "0"
    }else{
      ""
    }
    var thisMonth="${
      Calendar.getInstance().get(Calendar.YEAR)
    }-$monthPref${
      (Calendar.getInstance().get(Calendar.MONTH)+1)
    }%"

    val myDb: MyDatabase? = MyDatabase.getInstance(this@ExpenseDetailsActivity)
    var mSum = myDb?.expenseDao()?.getSumByMonth(thisMonth, model.id!!)

    if (mSum==null)
      mSum=0
    return mSum
  }
}
