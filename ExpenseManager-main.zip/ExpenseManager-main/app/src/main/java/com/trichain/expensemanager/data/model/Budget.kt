package com.trichain.expensemanager.data.model

import androidx.annotation.ColorRes
import com.trichain.expensemanager.extension.toMoneyFormatted

/**
 * Created by Yoosin Paddy on 8/15/22.
 */
data class Budget(
  val name: String,
  val total: Float,
  val spend: Float, @ColorRes val color: Int
) {
  val left = total - spend
  val desc = "$${spend.toMoneyFormatted(true)} / $${total.toMoneyFormatted(true)}"
}

data class BudgetOverview(
  val budgets: List<Budget>,
  val total: Float
)