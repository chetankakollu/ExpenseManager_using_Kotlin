package com.trichain.expensemanager.ui.overview

import android.animation.AnimatorListenerAdapter
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.*
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.Guideline
import androidx.core.view.children
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import com.google.android.material.button.MaterialButton
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.DataProvider
import com.trichain.expensemanager.databinding.FragmentOverviewBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.extension.toUSDFormatted
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import com.trichain.expensemanager.room.tables.NotificationTable
import com.trichain.expensemanager.ui.MainActivity
import com.trichain.expensemanager.ui.TabItem.ACCOUNT
import com.trichain.expensemanager.ui.TabItem.BILL
import com.trichain.expensemanager.ui.TabItem.BUDGET
import com.trichain.expensemanager.ui.budget.BudgetFragment
import com.trichain.expensemanager.ui.overview.adapter.AccountOverviewAdapter
import com.trichain.expensemanager.ui.overview.adapter.NotificationAdapter
import com.trichain.expensemanager.ui.overview.adapter.OverviewExpenseAdapter
import com.trichain.expensemanager.ui.overview.adapter.BudgetAdapter
import com.trichain.rally_line_indicator.data.RallyLineIndicatorData
import java.util.*
import kotlin.collections.ArrayList
import kotlin.collections.HashMap

/**
 * Created by Yoosin Paddy on 7/30/22.
 */
class OverviewFragment : Fragment() {
    private val TAG = "OverviewFragment"
    private val accountAdapter by lazy { AccountOverviewAdapter(isSingleLine = false) }
    lateinit var overviewExpenseAdapter: OverviewExpenseAdapter
    private lateinit var budgetAdapter: BudgetAdapter
    private lateinit var alertsAdapter: NotificationAdapter
    lateinit var b: FragmentOverviewBinding
    lateinit var expenseList: List<ExpenseTable>
    lateinit var budgetList: List<BudgetTable>
    var isInThisFragment=false
    private val content by lazy {
        requireView().findViewById<ViewGroup>(R.id.content)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        b = FragmentOverviewBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onResume() {
        super.onResume()
        isInThisFragment=true
        setUpAlertRecyclerView()
        setUpAccountRecyclerView()
        setUpExpenseRecyclerView()
        setUpBudgetRecyclerView()
        setUpClickListener()
    }

    override fun onPause() {
        super.onPause()
        isInThisFragment=false;
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)
        if (savedInstanceState == null) runEnterAnimation()

    }

    private fun setUpClickListener() {
        b.layoutAccountOverview?.btnAccSeeAll?.setOnClickListener {
            getParentActivity<MainActivity>().navigateToTabs(ACCOUNT)
        }
        b.layoutBillOverview.btnBillSeeAll.setOnClickListener {
            getParentActivity<MainActivity>().navigateToTabs(BILL)
        }
        b.layoutBudgetOverview.btnBudgetSeeAll.setOnClickListener {
            getParentActivity<MainActivity>().navigateToTabs(BUDGET)
        }
    }

    private fun setUpAlertRecyclerView() {
        var notificationList=getNotifications()
        alertsAdapter = NotificationAdapter(notificationList,requireContext(),true)
        b.rvAlert?.rvAlerts?.apply {
            layoutManager =
                LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)

            val snapHelper = PagerSnapHelper()
            snapHelper.attachToRecyclerView(this)

            setHasFixedSize(true)
            adapter = alertsAdapter
        }
        if (notificationList.size==0){
            b.rvAlert?.materialButton?.visibility= INVISIBLE
            b.rvAlert?.tvAlertTitle?.text="No alert, all Is Good"
        }else{

            b.rvAlert?.materialButton?.visibility= VISIBLE
            b.rvAlert?.tvAlertTitle?.text="Alerts"

        }

//        val alerts = DataProvider.alerts
//        alertsAdapter.submitList(alerts)
    }

    private fun getNotifications(): List<NotificationTable> {

        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
        var listNotif = myDb?.notificationDao()?.getAll() // get All data
        if (listNotif==null)
            listNotif=ArrayList<NotificationTable>()
        return listNotif
    }

    private fun setUpAccountOverview(lineIndicatorData: RallyLineIndicatorData) {
        b.layoutAccountOverview?.accountLineIndicator?.setData(lineIndicatorData)
        b.layoutAccountOverview?.tvAccountAmount?.text =
            DataProvider.accountOverView.total.toUSDFormatted()
    }

    private fun setUpAccountRecyclerView() {
//    b.layoutAccountOverview?.rvAccountOverview?.apply {
//      layoutManager = LinearLayoutManager(requireContext())
//      setHasFixedSize(true)
//      addItemDecoration(getRallyItemDecoration())
//      adapter = accountAdapter
//    }
//    accountAdapter.submitList(DataProvider.accountOverView.accounts.take(3))
//
//    val portions = DataProvider.accountOverView.accounts.take(3)
//        .map {
//          RallyLineIndicatorPortion(
//              name = it.name,
//              value = it.amount,
//              colorInt = ContextCompat.getColor(requireContext(), it.color)
//          )
//        }
//    setUpAccountOverview(RallyLineIndicatorData(portions = portions))
    }

    private fun setUpBillOverview(lineIndicatorData: RallyLineIndicatorData) {
        b.layoutBillOverview.billLineIndicator.setData(lineIndicatorData)
        b.layoutBillOverview.tvBillAmount.text = DataProvider.billOverView.total.toUSDFormatted()
    }

    private fun setUpExpenseRecyclerView() {
        getOverviewExpense()


    }

    private fun getOverviewExpense() {

        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
        val listExpense = myDb?.expenseDao()?.getAllL() // get All data
        if (listExpense != null) {
            listExpense.observe(requireActivity(), Observer {
                expenseList = it
                if (!isInThisFragment)
                    return@Observer
                overviewExpenseAdapter = OverviewExpenseAdapter(requireContext(), expenseList)
                b.layoutBillOverview.rvBillOverview.apply {
                    layoutManager = LinearLayoutManager(requireContext())
                    setHasFixedSize(true)
                    addItemDecoration(getRallyItemDecoration())
                    adapter = overviewExpenseAdapter
                }
                overviewExpenseAdapter.notifyDataSetChanged()
                if (it.size == 0) {
                    b.layoutBillOverview.btnBillSeeAll.text = "Add Some Expense"
                }
                b.layoutBillOverview.tvBillAmount.text =
                   "$${ expenseList.sumOf { e:ExpenseTable->e.amount }.toString()}"

            })
        }
    }

    private fun setUpBudgetOverview(lineIndicatorData: RallyLineIndicatorData) {
//        budgetAdapter = activity?.let {
//            BudgetAdapter(it, budgetList, true, object :
//                BudgetFragment {
//                override fun gotResults(catId: Int, amountLeft: Int) {
//
//                }
//            })
//        }!!
//        b.layoutBudgetOverview.budgetLineIndicator.setData(lineIndicatorData)
//        if (budgetList.size == 0) {
//            b.layoutBudgetOverview.btnBudgetSeeAll.text = "Add Budget"
//        }
//        b.layoutBudgetOverview.tvBudgetAmount.text =
//            DataProvider.budgetOverView.budgets.sumByDouble { it.spend.toDouble() }
//                .toFloat()
//                .toUSDFormatted()
//        b.layoutBudgetOverview.tvTotalBudget.text = "/ ${lineIndicatorData.maxValue?.toUSDFormatted()}"
    }

    private fun setUpBudgetRecyclerView() {

        val isTwoLine = requireContext().resources.configuration.smallestScreenWidthDp >= 600
        calculateBudgetLeft(0, 0)
        budgetList = getMyBudgetList()
        budgetAdapter = activity?.let {
            BudgetAdapter(it, budgetList, true, object :
                BudgetFragment.OnBudgetUpdated {
                override fun gotResults(catId: Int, amountLeft: Int) {

                    calculateBudgetLeft(catId, amountLeft)
                }

                override fun budgetClicked(budgetTable: BudgetTable) {

                    getParentActivity<MainActivity>().navigateToTabs(BUDGET,budgetTable)
                }
            })
        }!!
//        b.layoutBudgetOverview.budgetLineIndicator.setData(lineIndicatorData)
        if (budgetList.size == 0) {
            b.layoutBudgetOverview.btnBudgetSeeAll.text = "Add Budget"
            b.layoutBudgetOverview.amountLabelTv.visibility=View.GONE
            b.layoutBudgetOverview.amountLabel2Tv.visibility=View.GONE
//            b.layoutBudgetOverview.tvBudgetAmount.visibility=View.GONE
        } else {

            b.layoutBudgetOverview.btnBudgetSeeAll.text = "SEE ALL"
            b.layoutBudgetOverview.amountLabelTv.visibility=View.VISIBLE
//            b.layoutBudgetOverview.tvBudgetAmount.visibility=View.VISIBLE
            b.layoutBudgetOverview.amountLabel2Tv.visibility=View.INVISIBLE
        }

        b.layoutBudgetOverview.rvBudgetOverview.layoutManager =
            LinearLayoutManager(requireContext())
        b.layoutBudgetOverview.rvBudgetOverview.adapter = budgetAdapter
    }

    var budgetLeft = HashMap<Int, Int>()
    private fun calculateBudgetLeft(catId: Int, amountLeft: Int) {
        Log.e(TAG, "calculateBudgetLeft: ")
        budgetLeft.put(catId, amountLeft)
        var totalLeft: Int = 0
        budgetLeft.forEach {
            totalLeft += it.value
        }
        if (totalLeft < 0) {
            b.layoutBudgetOverview.tvBudgetAmount.text = "$${(totalLeft * -1).toString()}"
            b.layoutBudgetOverview.amountLabelTv.text = "Overspent"
        } else {
            b.layoutBudgetOverview.tvBudgetAmount.text = "$${(totalLeft).toString()}"
            b.layoutBudgetOverview.amountLabelTv.text = "Left"
        }
    }

    private fun getMyBudgetList(): List<BudgetTable> {
        var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
            "0"
        }else{
            ""
        }
        val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
        var listBudgets = myDb?.budgetDao()?.getSpecificPeriod(
            "${
                Calendar.getInstance().get(Calendar.YEAR)
            }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)}%"
        ) // get All data
        if (listBudgets == null)
            listBudgets = ArrayList<BudgetTable>()
        Log.e(TAG, "getMyBudgetList: ${listBudgets.size}")
        return listBudgets
    }

    private fun showDialogForAlert(alert: String) {
        val dialog = Dialog(requireContext(), R.style.Widget_Rally_AlertDialog).apply {
            setCancelable(true)
            setContentView(R.layout.dialog_alert)

            val width = if (resources.configuration.smallestScreenWidthDp >= 600) {
                resources.displayMetrics.widthPixels * 0.65
            } else {
                resources.displayMetrics.widthPixels * 0.8
            }

            window?.setLayout(width.toInt(), LayoutParams.WRAP_CONTENT)

            findViewById<TextView>(R.id.tv_alert_title).text = alert
            findViewById<MaterialButton>(R.id.btnDismiss).setOnClickListener {
                dismiss()
            }
        }
        dialog.show()
    }

    private fun runEnterAnimation() {
        content.post {
            var duration = 300L
            content.children.filterNot { it is Guideline }
                .forEach { child ->
                    duration += 100
                    child.translationY += 400
                    child.alpha = 0f
                    child.animate()
                        .translationY(0f)
                        .alpha(1f)
                        .setDuration(duration)
                        .setInterpolator(DecelerateInterpolator())
                        .setListener(object : AnimatorListenerAdapter() {
                        })
                        .start()
                }
        }
    }

}

fun <T : AppCompatActivity> Fragment.getParentActivity(): T {
    return requireActivity() as T
}

