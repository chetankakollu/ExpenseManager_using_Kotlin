package com.trichain.expensemanager.ui.info

import android.os.Bundle
import android.view.ContextThemeWrapper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.trichain.expensemanager.R
import com.trichain.expensemanager.R.style

/**
 * Created by Yoosin Paddy on 8/29/22.
 */
class InfoFragment : BottomSheetDialogFragment() {

  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    val contextThemeWrapper = ContextThemeWrapper(activity, style.Rally_DayNight)
    return inflater.cloneInContext(contextThemeWrapper).inflate(R.layout.sheet_info, container, false)
  }
}