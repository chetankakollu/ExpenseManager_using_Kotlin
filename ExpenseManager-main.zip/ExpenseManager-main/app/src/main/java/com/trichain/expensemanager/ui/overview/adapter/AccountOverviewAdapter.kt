package com.trichain.expensemanager.ui.overview.adapter

import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.model.Account
import com.trichain.expensemanager.extension.inflate
import com.trichain.expensemanager.extension.toMoneyFormatted
import com.trichain.expensemanager.ui.detail.DetailActivity
import com.trichain.rally_line_indicator.RallyVerticalBar
import com.trichain.rally_line_indicator.RallyVerticalBarData

/**
 * Created by Yoosin Paddy on 7/31/22.
 */
class AccountOverviewAdapter(val isSingleLine: Boolean) : ListAdapter<Account, AccountOverviewViewHolder>(object :
    DiffUtil.ItemCallback<Account>() {
  override fun areItemsTheSame(
    oldItem: Account,
    newItem: Account
  ): Boolean {
    return oldItem.name == newItem.name
  }

  override fun areContentsTheSame(
    oldItem: Account,
    newItem: Account
  ): Boolean {
    return oldItem == newItem
  }
}) {

  override fun onCreateViewHolder(
    parent: ViewGroup,
    viewType: Int
  ): AccountOverviewViewHolder {
    if (isSingleLine) {
      return AccountOverviewViewHolder(parent.inflate(R.layout.item_account_single_row))
    }
    return AccountOverviewViewHolder(parent.inflate(R.layout.item_account))
  }

  override fun onBindViewHolder(
    holder: AccountOverviewViewHolder,
    position: Int
  ) {
    holder.bind(getItem(position))
  }
}

class AccountOverviewViewHolder(val view: View) : RecyclerView.ViewHolder(view) {

  private val barView: RallyVerticalBar = view.findViewById(R.id.bar)
  private val tvName: TextView = view.findViewById(R.id.tvName)
  private val tvDescription: TextView = view.findViewById(R.id.tvDesc)
  private val tvAmount: TextView = view.findViewById(R.id.tvAmount)

  fun bind(model: Account) {

    barView.renderData(RallyVerticalBarData(100f, 100f, model.color))
    tvName.text = model.name
    tvDescription.text = model.desc
    tvAmount.text = model.amount.toMoneyFormatted()

    view.setOnClickListener {
//      DetailActivity.start(view.context, view, model)
    }
  }
}
