package com.trichain.expensemanager.ui.detail

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.DataProvider
import com.trichain.expensemanager.databinding.FragmentMonthlyBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import java.util.*
import kotlin.collections.ArrayList

//import kotlinx.android.synthetic.main.fragment_monthly.rv_monthly

/**
 * Created by Yoosin Paddy on 8/4/22.
 */
class MonthlyFragment : Fragment() {
lateinit var b:FragmentMonthlyBinding
  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View? {
    b= FragmentMonthlyBinding.inflate(inflater,container,false)
    return b.root
  }

  override fun onViewCreated(
    view: View,
    savedInstanceState: Bundle?
  ) {
    super.onViewCreated(view, savedInstanceState)

    setUpRecyclerView()
  }

  private fun setUpRecyclerView() {
    b.rvMonthly.apply {
      layoutManager = LinearLayoutManager(requireContext())
      setHasFixedSize(true)
      addItemDecoration(getRallyItemDecoration())
      adapter = MonthlyAdapter(getExpenses(arguments?.getInt(KEY_MONTH) ?: 1))
    }
  }

  private fun getExpenses(p: Int): List<ExpenseTable> {

    var c = Calendar.getInstance()
    c.set(Calendar.DAY_OF_MONTH, 1)
    if (p != 0) {
      c.add(Calendar.MONTH, (-1 * p))
    }
    var monthPref = if ((c.get(Calendar.MONTH) + 1) < 10) {
      "0"
    } else {
      ""
    }
    var thisMonth = "${
      c.get(Calendar.YEAR)
    }-$monthPref${
      (c.get(Calendar.MONTH) + 1)
    }-%"
    Log.e(TAG, "getDataFor: $thisMonth", )
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())
    var mSum = myDb?.expenseDao()?.getListByMonth(thisMonth, (arguments?.getSerializable("category") as  CategoryTable).id!!)
    if (mSum == null)
      mSum = ArrayList()
    Log.e(TAG, "getExpenses: $mSum", )
    return mSum
  }

  companion object {
    private const val TAG = "MonthlyFragment"
    private const val KEY_MONTH = "key-month"
    fun newInstance(month: Int, categoryTable: CategoryTable): MonthlyFragment {
      return MonthlyFragment().apply {
        arguments = Bundle().apply { putInt(KEY_MONTH, month)
        putSerializable("category",categoryTable)}
      }
    }
  }
}
