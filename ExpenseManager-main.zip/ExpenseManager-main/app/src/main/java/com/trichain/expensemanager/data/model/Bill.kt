package com.trichain.expensemanager.data.model

import androidx.annotation.ColorRes

/**
 * Created by Yoosin Paddy on 8/15/22.
 */
data class Bill(val name: String,val desc:String,val amount:Float, @ColorRes val color:Int)

data class BillOverView(val total:Float,val bills:List<Bill>)