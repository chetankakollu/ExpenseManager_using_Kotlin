package com.trichain.expensemanager.data.model

import androidx.annotation.ColorRes

/**
 * Created by Yoosin Paddy on 8/15/22.
 */
data class Account(val name: String,val desc:String,val amount:Float, @ColorRes val color:Int)

data class AccountOverView(val total:Float,val accounts:List<Account>)