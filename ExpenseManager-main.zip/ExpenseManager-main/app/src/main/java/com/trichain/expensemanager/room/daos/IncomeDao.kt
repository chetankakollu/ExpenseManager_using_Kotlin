package com.trichain.expensemanager.room.daos

import androidx.lifecycle.LiveData
import androidx.room.*
import androidx.room.OnConflictStrategy.REPLACE
import com.trichain.expensemanager.room.tables.BudgetTable
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import com.trichain.expensemanager.room.tables.IncomeTable

@Dao
interface IncomeDao {
    @Insert(onConflict = REPLACE)
    fun insert(data: IncomeTable)

    @Delete
    fun delete(data: IncomeTable)

    @Update
    fun update(data: IncomeTable): Int

    @Query("SELECT * from IncomeTable ORDER BY id ASC")
    fun getAll(): List<IncomeTable>


    @Query("SELECT * from IncomeTable ORDER BY id ASC")
    fun getAllL(): LiveData<List<IncomeTable>>

    @Query("SELECT * FROM IncomeTable WHERE id = :id LIMIT 1")
    fun getNote(id: Int): IncomeTable

    @Query("DELETE FROM IncomeTable")
    fun deleteAll(): Int
}