package com.trichain.expensemanager.ui.overview.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.databinding.ItemExpenseBinding
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import com.trichain.expensemanager.ui.detail.DetailActivity
import com.trichain.rally_line_indicator.RallyVerticalBarData

/**
 * Created by Yoosin Paddy on 7/31/22.
 */
class OverviewExpenseAdapter(var c: Context, var categories:List<ExpenseTable>) : RecyclerView.Adapter<BillViewHolder>() {
  override fun onCreateViewHolder(
    parent: ViewGroup,
    viewType: Int
  ): BillViewHolder {
    return BillViewHolder(ItemExpenseBinding.inflate(LayoutInflater.from(c),parent,false))
  }

  override fun onBindViewHolder(
    holder: BillViewHolder,
    position: Int
  ) {
    holder.bind(categories[position],c)
  }

  override fun getItemCount(): Int {
    return  if(categories.size>3){3}else{categories.size}
  }
}

class BillViewHolder(val b:  ItemExpenseBinding) : RecyclerView.ViewHolder(b.root) {

  fun bind(model: ExpenseTable,c: Context) {
    b.bar.renderData(RallyVerticalBarData(100f, 100f, model.getColor()))
    b.tvName.text = model.name
    b.tvAmount.text = model.amount.toString()

    b.ivArrow.visibility= View.GONE
//    b.ivArrow.setOnClickListener {
//      DetailActivity.start(c, b.shareView, model.getColor())
//    }
  }
}

