package com.trichain.expensemanager.room.tables

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Ignore
import androidx.room.PrimaryKey
import com.trichain.expensemanager.R
import kotlin.random.Random

@Entity
class ExpenseTable {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    var id: Int? = null

    var userId: Int = 0

    var categoryId: Int = 0

    var amount: Int = 0

    lateinit var name: String

    lateinit var mDate: String//YYYY-MM-dd

    constructor()

    @Ignore
    constructor(mDate: String) {
        this.mDate = mDate
    }

    fun getColor(): Int {
        val mColor = listOf<Int>(
            R.color.rally_yellow,
            R.color.rally_yellow,
            R.color.rally_orange,
            R.color.rally_yellow_500,
            R.color.rally_yellow,
            R.color.rally_orange,
            R.color.rally_yellow_500,
            R.color.rally_yellow,
            R.color.rally_orange,
            R.color.rally_yellow_500,
            R.color.rally_yellow,
        )
        return if (id != null) {
            mColor[(id!!.rem(11))]
        } else {
            mColor[(0..10).random()]
        }
    }

    override fun toString(): String {
        return "userid:$userId\n" +
                "catId:$categoryId\n" +
                "amount:$amount\n" +
                "name:$name\n" +
                "date:$mDate"
    }
}