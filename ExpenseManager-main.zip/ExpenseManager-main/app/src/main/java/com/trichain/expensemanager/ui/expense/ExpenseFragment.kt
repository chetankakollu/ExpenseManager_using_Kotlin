package com.trichain.expensemanager.ui.expense

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.LinearLayoutManager
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.SharedPrefsManager
import com.trichain.expensemanager.databinding.DialogAddExpenseBinding
import com.trichain.expensemanager.databinding.FragmentExpenseBinding
import com.trichain.expensemanager.extension.getRallyItemDecoration
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.room.tables.ExpenseTable
import com.trichain.expensemanager.room.tables.NotificationTable
import com.trichain.expensemanager.ui.MainActivity
import com.trichain.expensemanager.ui.info.InfoFragment
import com.trichain.expensemanager.ui.overview.adapter.ExpenseAdapter
import com.trichain.expensemanager.ui.overview.getParentActivity
import com.trichain.rally_pie.RallyPieAnimation
import com.trichain.rally_pie.RallyPieData
import com.trichain.rally_pie.RallyPiePortion
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers
import java.text.Format
import java.text.SimpleDateFormat
import java.util.*

/**
 * Created by Yoosin Paddy on 8/13/22.
 */
class ExpenseFragment : Fragment() {
  private val TAG = "ExpenseFragment"
  lateinit var expenseList: List<ExpenseTable>

  lateinit var categoryList: List<CategoryTable>
  private lateinit var expenseAdapter :ExpenseAdapter
lateinit var b:FragmentExpenseBinding
  override fun onCreateView(
    inflater: LayoutInflater,
    container: ViewGroup?,
    savedInstanceState: Bundle?
  ): View {
    b= FragmentExpenseBinding.inflate(inflater,container,false)
    return b.root
  }

  override fun onViewCreated(
    view: View,
    savedInstanceState: Bundle?
  ) {
    super.onViewCreated(view, savedInstanceState)

    b.btnInfo.setOnClickListener {
      val infoFragment = InfoFragment()
      infoFragment.show(childFragmentManager, "BillInfo")
    }
  }

  override fun onResume() {
    super.onResume()
    setUpRecyclerView()
    b.addFab?.setOnClickListener {
      var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
        "0"
      }else{
        ""
      }
      var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
        "0"
      }else{
        ""
      }
      addExpense(
        ExpenseTable(
          "${Calendar.getInstance().get(Calendar.YEAR)
          }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)
          }-$dayPref${Calendar.getInstance().get(Calendar.DATE)}"
        )
      )
    }
  }

  private fun addExpense(expenseTable: ExpenseTable) {

    var item=expenseTable
    val dialog = Dialog(requireContext(), R.style.Widget_Rally_AlertDialog).apply {
      setCancelable(true)
      val view = DialogAddExpenseBinding.inflate(LayoutInflater.from(requireContext()))
      setContentView(view.root)

      val width = if (resources.configuration.smallestScreenWidthDp >= 600) {
        resources.displayMetrics.widthPixels * 0.65
      } else {
        resources.displayMetrics.widthPixels * 0.8
      }

      window?.setLayout(width.toInt(), ViewGroup.LayoutParams.WRAP_CONTENT)
      val categories = getMyCategories()

      val arraySpinner = categories.map { it.name }.toTypedArray()
      val adapter: ArrayAdapter<String> = ArrayAdapter<String>(
        requireContext(),
        android.R.layout.simple_spinner_item, arraySpinner
      )
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
      view.categorySpinner.setAdapter(adapter)
      if (item.categoryId != 0) {
        categories.forEachIndexed { p, it ->
          if (it.id == item.id) {
            view.categorySpinner.setSelection(p)
          }
        }
      }
      if (item.amount != 0) {
        view.editAMount.setText(item.amount.toString())
      }

      view.btnDismiss.setOnClickListener {
        if (view.editAMount.text.toString().isEmpty()) {
          view.amountIL.error = "Please fill this"
          view.editAMount.requestFocus()
        } else if (view.nameEd.text.toString().isEmpty()) {
          view.nameIL.error = "Please fill this"
          view.editAMount.requestFocus()
        } else {
          var carId = 0
          categories.forEach {
            if (it.name.contentEquals(view.categorySpinner.selectedItem as String)) {
              carId = it.id!!
            }
          }
          item.categoryId = carId
          item.amount = view.editAMount.text.toString().toInt()
          item.name = view.nameEd.text.toString()
          item.userId = SharedPrefsManager.getInstance(requireContext())?.getUserId()!!

          insert(item)
          dismiss()
        }
      }

    }

    dialog.show()
  }

  fun insert(mItem: ExpenseTable) {
    Log.e(TAG, "insert: ${mItem.toString()}", )
    var item = mItem
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())

    CompositeDisposable().add(Observable.fromCallable { myDb?.expenseDao()?.insert(item) }
      .subscribeOn(Schedulers.computation())
      .observeOn(AndroidSchedulers.mainThread())
      .subscribe {
        Log.e(TAG, "data updated")
        setUpRecyclerView()
        checkForAlert(item)
      })
  }

  val f: Format = SimpleDateFormat("MMM, yyyy")
  val f2: Format = SimpleDateFormat("dd MMM, yyyy")
  private fun checkForAlert(item: ExpenseTable) {
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())

    var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
      "0"
    }else{
      ""
    }
    var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
      "0"
    }else{
      ""
    }
      var mMonth=  "${Calendar.getInstance().get(Calendar.YEAR)
        }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)
        }-%"
      var mDay=  "${Calendar.getInstance().get(Calendar.YEAR)
        }-$monthPref${(Calendar.getInstance().get(Calendar.MONTH)+1)
        }-$dayPref${(Calendar.getInstance().get(Calendar.DAY_OF_MONTH))
        }"

    var totalMonthlyBudget=myDb?.budgetDao()?.getSumForOneSpecificPeriod(mMonth, item.categoryId,"Monthly")
    Log.e(TAG, "checkForAlert-totalMonthlyBudget: $totalMonthlyBudget", )
    var totalMonthlyExpenditure=myDb?.expenseDao()?.getSumByMonth(mMonth, item.categoryId)
    Log.e(TAG, "checkForAlert-totalMonthlyExpenditure: $totalMonthlyExpenditure", )
    var totalDailyBudget=myDb?.budgetDao()?.getSumForOneSpecificPeriod(mMonth, item.categoryId,"Daily")
    Log.e(TAG, "checkForAlert-totalDailyBudget: $totalDailyBudget", )
    var totalDailyExpenditure=myDb?.expenseDao()?.getSumByMonth(mDay, item.categoryId)
    Log.e(TAG, "checkForAlert-totalDailyExpenditure: $totalDailyExpenditure", )
    val category=myDb?.categoryDao()?.getCategory(item.categoryId)
    if (totalMonthlyBudget!=0&&totalMonthlyBudget!!< totalMonthlyExpenditure!!){
      //monthly alert
      val strMonth: String = f.format(Calendar.getInstance().time)
      var mAlert=myDb?.notificationDao()?.getNotification(item.categoryId,mMonth,SharedPrefsManager.getInstance(requireContext())?.getUserId()!!)
      if (mAlert==null){
        mAlert= NotificationTable()
        mAlert.username=SharedPrefsManager.getInstance(requireContext())?.getUserId()!!
        mAlert.categoryId=item.categoryId
        mAlert.mDate=mDay
        mAlert.info="You have overspent $${(totalMonthlyExpenditure-totalMonthlyBudget)} in $strMonth for ${category?.name}"
        showNotification("Monthly Limit Exceeded",mAlert)
      }else{
        mAlert.info="You have overspent $${(totalMonthlyExpenditure-totalMonthlyBudget)} in $strMonth for ${category?.name}"
      }
      CompositeDisposable().add(Observable.fromCallable { myDb?.notificationDao()?.insert(mAlert) }
        .subscribeOn(Schedulers.computation())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe {
          Log.e(TAG, "data updated")
          setUpRecyclerView()
        })
    }
    if (totalDailyBudget!=0&&totalDailyBudget!!< totalDailyExpenditure!!){
      //daily alert
      val strDay: String = f2.format(Calendar.getInstance().time)
      var dAlert=myDb?.notificationDao()?.getNotification(item.categoryId,mDay,SharedPrefsManager.getInstance(requireContext())?.getUserId()!!)
      if (dAlert==null){
        dAlert= NotificationTable()
        dAlert.username=SharedPrefsManager.getInstance(requireContext())?.getUserId()!!
        dAlert.categoryId=item.categoryId
        dAlert.mDate=mDay
        dAlert.info="You have overspent $${(totalDailyExpenditure-totalDailyBudget)} in $strDay in ${category?.name}"
        showNotification("Daily Limit Exceeded",dAlert)
      }else{
        dAlert.info="You have overspent $${(totalDailyExpenditure-totalDailyBudget)} in $strDay in ${category?.name}"
      }
      CompositeDisposable().add(Observable.fromCallable { myDb?.notificationDao()?.insert(dAlert) }
        .subscribeOn(Schedulers.computation())
        .observeOn(AndroidSchedulers.mainThread())
        .subscribe {
          Log.e(TAG, "data updated")
          setUpRecyclerView()
        })
    }

  }

  private fun showNotification(title: String, dAlert: NotificationTable) {
    Log.e(TAG, "showNotification: " )
    val channelId = requireActivity().packageName
    val description = "Expense Notification"

    val notificationManager: NotificationManager= requireActivity().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    lateinit var notificationChannel: NotificationChannel
    lateinit var builder: Notification.Builder
    // pendingIntent is an intent for future use i.e after
    // the notification is clicked, this intent will come into action
    val intent = Intent(requireContext(), MainActivity::class.java)

    // FLAG_UPDATE_CURRENT specifies that if a previous
    // PendingIntent already exists, then the current one
    // will update it with the latest intent
    // 0 is the request code, using it later with the
    // same method again will get back the same pending
    // intent for future reference
    // intent passed here is to our afterNotification class
    val pendingIntent = PendingIntent.getActivity(requireContext(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

    // RemoteViews are used to use the content of
    // some different layout apart from the current activity layout

    // checking if android version is greater than oreo(API 26) or not
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      notificationChannel = NotificationChannel(channelId, description, NotificationManager.IMPORTANCE_HIGH)
      notificationChannel.enableLights(true)
      notificationChannel.lightColor = Color.GREEN
      notificationChannel.enableVibration(false)
      notificationManager.createNotificationChannel(notificationChannel)

      builder = Notification.Builder(requireContext(), channelId)
        .setSmallIcon(R.drawable.ic_launcher_background)
        .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.drawable.ic_launcher_background))
        .setContentIntent(pendingIntent)
        .setContentTitle(title)
        .setContentText(dAlert.info)
    } else {

      builder = Notification.Builder(requireContext())
        .setSmallIcon(R.drawable.ic_launcher_background)
        .setLargeIcon(BitmapFactory.decodeResource(this.resources, R.drawable.ic_launcher_background))
        .setContentIntent(pendingIntent)
        .setContentTitle(title)
        .setContentText(dAlert.info)
    }
    notificationManager.notify(1234, builder.build())


  }

  private fun getMyCategories(): List<CategoryTable> {
//        if (categoryList==null||categoryList.size > 0) {
//            return categoryList
//        }
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
    if (myDb?.categoryDao()?.getAll() != null) {
      categoryList = myDb?.categoryDao()?.getAll()
    } // get All data
    if (categoryList == null)
      categoryList = ArrayList<CategoryTable>()
    return categoryList

  }
  private fun setUpPieView() {
    val rallyPiePortions = categoryList.map {
      RallyPiePortion(
          it.name, getExpenseAmountFromCategory(it).toFloat(), ContextCompat.getColor(requireContext(), it.getColor())
      )
    }
        .toList()
    val rallyPieData = RallyPieData(portions = rallyPiePortions)
    val rallyPieAnimation = RallyPieAnimation(b.rallyPie).apply {
      duration = 600
    }


    b.rallyPie.setPieData(pieData = rallyPieData, animation = rallyPieAnimation)
  }

  private fun setUpRecyclerView() {
    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext()) // call database
    val listExpense = myDb?.categoryDao()?.getAllL() // get All data
    if (listExpense != null) {
      listExpense.observe(requireActivity(), Observer {
        categoryList = it

        expenseAdapter=  ExpenseAdapter(requireContext(),categoryList,object: OnExpenseUpdated{
          override fun clicked(categoryTable: CategoryTable) {

            val intent = Intent(requireContext(),ExpenseDetailsActivity::class.java)
            intent.putExtra("category",categoryTable)
            getParentActivity<MainActivity>().startActivity(intent)
          }

        })
        b.rvBill.apply {
          layoutManager = LinearLayoutManager(requireContext())
          setHasFixedSize(true)
          addItemDecoration(getRallyItemDecoration())
          adapter = expenseAdapter
        }
        expenseAdapter.notifyDataSetChanged()
        if (it.size == 0) {
          b.rallyPie.visibility=View.GONE
          b.noExpenseTv?.visibility  =View.VISIBLE
          b.tvAmount?.visibility  =View.GONE
          b.btnInfo?.visibility  =View.GONE
        }else{
          b.rallyPie.visibility=View.VISIBLE
          b.tvAmount.visibility=View.VISIBLE
          b.btnInfo.visibility=View.VISIBLE
          b.noExpenseTv?.visibility=View.GONE
          b.tvAmount.text=it.sumOf { e:CategoryTable->getExpenseAmountFromCategory(e) }.toString()

        }
        setUpPieView()
      })
    }

  }

  private fun getExpenseAmountFromCategory(model: CategoryTable) :Int{

    var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
      "0"
    }else{
      ""
    }
    var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
      "0"
    }else{
      ""
    }
    var thisMonth="${
      Calendar.getInstance().get(Calendar.YEAR)
    }-$monthPref${
      (Calendar.getInstance().get(Calendar.MONTH)+1)
    }%"

    val myDb: MyDatabase? = MyDatabase.getInstance(requireContext())
    var mSum = myDb?.expenseDao()?.getSumByMonth(thisMonth, model.id!!)

    if (mSum==null)
      mSum=0
    return mSum
  }

  interface OnExpenseUpdated {
    fun clicked(categoryTable: CategoryTable)
  }
}
