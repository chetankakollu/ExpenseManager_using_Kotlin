package com.trichain.expensemanager.data

import com.trichain.expensemanager.room.tables.CategoryTable

class Utils {
    fun initialCategories():List<CategoryTable>{
        return listOf<CategoryTable>(
            CategoryTable("Housing and Utilities",1),
            CategoryTable("Transportation",1),
            CategoryTable("Food and Drinks",1),
            CategoryTable("Shopping",1),
            CategoryTable("Entertainment",1))

    }


}