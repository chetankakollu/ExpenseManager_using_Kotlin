package com.trichain.expensemanager.ui.auth

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.EditorInfo
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.interpolator.view.animation.FastOutSlowInInterpolator
import com.trichain.expensemanager.R
import com.trichain.expensemanager.data.Authenticator
import com.trichain.expensemanager.databinding.ActivityRegisterBinding
import com.trichain.expensemanager.ui.MainActivity
//import kotlinx.android.synthetic.main.activity_register.*

/**
 * Created by Yoosin Paddy on 8/18/22.
 */
class RegisterActivity : AppCompatActivity() {

    private lateinit var authenticator: Authenticator
lateinit var b:ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b=DataBindingUtil.setContentView(this,R.layout.activity_register)

        authenticator = Authenticator(applicationContext)
        if (authenticator.isLoggedIn()) {
            authenticator.logOut()
        }

//
//    (application as RallyApp).preferenceRepository
//        .nightModeLive.observe(this, Observer { nightMode ->
//      nightMode?.let { delegate.localNightMode = it }
//    })
//



        if (savedInstanceState == null) runEnterAnimation()

        setUpInputField()

        b.constraintLayout.setOnClickListener { register() }
//    iv_fingerprint.setOnClickListener { login() }
        b.labelLoginId.setOnClickListener { goToLogin(b.labelLoginId) }
        b.imgLogo.setOnClickListener { register() }
    }

    private fun setUpInputField() {
        b.inputEmail.isEndIconVisible = false
        b.etEmail.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(editable: Editable?) {
                b.inputEmail.isEndIconVisible = editable?.toString()?.trim() == "user@rally"

            }

            override fun beforeTextChanged(
                p0: CharSequence?,
                p1: Int,
                p2: Int,
                p3: Int
            ) {
            }

            override fun onTextChanged(
                p0: CharSequence?,
                p1: Int,
                p2: Int,
                p3: Int
            ) {
            }

        })
//    b.etEmail.setText("user@rally")


        b.etPwd.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                register()
                true
            }
            false
        }
    }

    private fun register() {
        val email = b.etEmail.text?.toString()
            ?.trim()
        val password = b.etPwd.text?.toString()
            ?.trim()
        val name = b.etName.text?.toString()
            ?.trim()
        if (email.isNullOrEmpty()) {
            b.etEmail.setError("Please fill this")
            b.etEmail.requestFocus()
            return
        } else if (password.isNullOrEmpty()) {
            b.etPwd.setError("Please fill this")
            b.etPwd.requestFocus()
            return
        } else if (name.isNullOrEmpty()) {
            b.etName.setError("Please fill this")
            b.etName.requestFocus()
            return
        }
        if (authenticator.register(name, email, password)) {
            navigateToLogin()
        }
    }

    private fun navigateToLogin() {
        super.onBackPressed()
    }

    private fun runEnterAnimation() {
        b.inputName.alpha = 0f
        b.inputName.scaleX = 1.05f
        b.inputEmail.alpha = 0f
        b.inputEmail.scaleX = 1.05f
//    iv_fingerprint.alpha = 0f
        b.labelLoginId.alpha = 0f

        findViewById<View>(android.R.id.content).post {
            val startY = resources.displayMetrics.heightPixels / 2 - b.imgLogo.height / 2f
            val endY = b.imgLogo.y

            b.imgLogo.y = startY
            b.inputName.translationY += b.inputName.height
            b.inputEmail.translationY += b.inputEmail.height
//      iv_fingerprint.translationY += iv_fingerprint.height
            b.labelLoginId.translationY += b.inputEmail.height

            val logoAnimator = ObjectAnimator.ofFloat(b.imgLogo, View.Y, startY, endY)
            logoAnimator.duration = DURATION

            val emailInputAnimator = ObjectAnimator.ofPropertyValuesHolder(
                b.inputName,
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f)
            )
            emailInputAnimator.startDelay = 250
            emailInputAnimator.duration = 250

            val pwdInputAnimator = ObjectAnimator.ofPropertyValuesHolder(
                b.inputEmail,
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f),
                PropertyValuesHolder.ofFloat(View.SCALE_X, 1f)
            )
            pwdInputAnimator.startDelay = 250
            pwdInputAnimator.duration = 250

//      val ivFingerPrintAnimator = ObjectAnimator.ofPropertyValuesHolder(
//          iv_fingerprint,
//          PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f),
//          PropertyValuesHolder.ofFloat(View.ALPHA, 1f)
//      )
//      ivFingerPrintAnimator.startDelay = 300
//      ivFingerPrintAnimator.duration = 200

            val labelAnimator = ObjectAnimator.ofPropertyValuesHolder(
                b.labelLoginId,
                PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, 0f),
                PropertyValuesHolder.ofFloat(View.ALPHA, 1f)
            )
            labelAnimator.startDelay = 400
            labelAnimator.duration = 100

            val set = AnimatorSet()
            set.interpolator = FastOutSlowInInterpolator()
            set.playTogether(
                logoAnimator,
                emailInputAnimator,
                pwdInputAnimator, /*ivFingerPrintAnimator,*/
                labelAnimator
            )
            set.start()
        }
    }

    companion object {
        private const val DURATION = 500L
    }

    fun goToLogin(view: View) {
        startActivity(Intent(this, LoginActivity::class.java))
    }
}
