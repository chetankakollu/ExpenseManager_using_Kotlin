package com.trichain.expensemanager.ui.overview.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.databinding.ItemExpenseBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import com.trichain.expensemanager.ui.detail.DetailActivity
import com.trichain.expensemanager.ui.expense.ExpenseFragment
import com.trichain.rally_line_indicator.RallyVerticalBarData
import java.util.*

/**
 * Created by Yoosin Paddy on 7/31/22.
 */
class ExpenseAdapter(
  var c: Context,
  var categories: List<CategoryTable>,
  param: ExpenseFragment.OnExpenseUpdated
) : RecyclerView.Adapter<ExpenseViewHolder>() {
  override fun onCreateViewHolder(
    parent: ViewGroup,
    viewType: Int
  ): ExpenseViewHolder {
    return ExpenseViewHolder(ItemExpenseBinding.inflate(LayoutInflater.from(c),parent,false))
  }

  override fun onBindViewHolder(
    holder: ExpenseViewHolder,
    position: Int
  ) {
    holder.bind(categories[position],c)
  }

  override fun getItemCount(): Int {
    return  categories.size
  }
}

class ExpenseViewHolder(val b:  ItemExpenseBinding) : RecyclerView.ViewHolder(b.root) {

  fun bind(model: CategoryTable,c: Context) {
    b.bar.renderData(RallyVerticalBarData(100f, 100f, model.getColor()))
    b.tvName.text = model.name
    getExpenseAmountFromCategory(model,c,b)
    //b.tvAmount.text = model.amount.toString()

    b.ivArrow.setOnClickListener {
      DetailActivity.start(c, b.shareView, model)
    }
  }

  private fun getExpenseAmountFromCategory(model: CategoryTable, c: Context, b: ItemExpenseBinding) {

    var monthPref=if((Calendar.getInstance().get(Calendar.MONTH)+1)<10){
      "0"
    }else{
      ""
    }
    var dayPref=if(Calendar.getInstance().get(Calendar.DATE)<10){
      "0"
    }else{
      ""
    }
    var thisMonth="${
          Calendar.getInstance().get(Calendar.YEAR)
        }-$monthPref${
          (Calendar.getInstance().get(Calendar.MONTH)+1)
        }%"

    val myDb: MyDatabase? = MyDatabase.getInstance(c.applicationContext)
    val mSum = myDb?.expenseDao()?.getSumByMonth(thisMonth, model.id!!)
    b.tvAmount.text=mSum.toString()
  }
}

