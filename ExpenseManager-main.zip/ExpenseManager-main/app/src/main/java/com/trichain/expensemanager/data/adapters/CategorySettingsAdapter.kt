package com.trichain.expensemanager.data.adapters

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.trichain.expensemanager.databinding.DialogEditCategoryBinding
import com.trichain.expensemanager.databinding.ItemCategoryEditBinding
import com.trichain.expensemanager.room.MyDatabase
import com.trichain.expensemanager.room.tables.CategoryTable
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class CategorySettingsAdapter(var c: Context, var categories: List<CategoryTable>) :
    RecyclerView.Adapter<CategorySettingsAdapter.CategorySettingsVH>() {
    private val TAG = "CategorySettingsAdapter"

    class CategorySettingsVH(v: ItemCategoryEditBinding) : RecyclerView.ViewHolder(v.root) {
        var b = v
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategorySettingsVH {
        return CategorySettingsVH(
            ItemCategoryEditBinding.inflate(
                LayoutInflater.from(c),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: CategorySettingsVH, position: Int) {
        Log.e(TAG, "onBindViewHolder: $position" )
        holder.b.tvName.text = categories[position].name
        holder.b.ivArrow.setOnClickListener {
            var a = AlertDialog.Builder(c)
            var v = DialogEditCategoryBinding.inflate(LayoutInflater.from(c))
            a.setView(v.root)
            var t=a.create()
            v.editCategory.setText(categories[position].name)
            v.btnDismiss.setOnClickListener {
                if (v.editCategory.text.isNullOrEmpty()) {
                    v.editCategory.setError("Please fill this")
                    v.editCategory.requestFocus()
                } else {
                    categories[position].name = v.editCategory.text.toString()
                    saveCategory(categories[position].apply {
                        name = v.editCategory.text.toString()
                    })
                    t.dismiss()
                }
            }
            t.show()

        }
    }

    private fun saveCategory(note: CategoryTable) {

        val myDb: MyDatabase? = MyDatabase.getInstance(c) //

        CompositeDisposable().add(
            Observable.fromCallable {
                if (note != null) {
                    myDb?.categoryDao()?.update(note)
                }
            }.subscribeOn(Schedulers.computation())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe {
                    Log.d("respons", "data updated")
                })
    }

    override fun getItemCount(): Int {
        return categories.size
    }
}